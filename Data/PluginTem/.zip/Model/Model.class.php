<?php

/**
 * 模型
 */
class Model extends Model{

}
