<?php

import('Class.Plugin', APP_PATH);

/**
 * 插件
 * @author 
 */

    class Plugin extends Plugin{

        public $info = array(
            'name'=>'',
            'title'=>'',
            'description'=>' ',
            'status'=>1,
            'author'=>'',
            'version'=>''
        );

        public function install(){
            return true;
        }

        public function uninstall(){
            return true;
        }


    }