<?php

/**
 * bbb模型
 */
class bbbModel extends Model{

}
