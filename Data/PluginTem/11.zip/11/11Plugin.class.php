<?php

import('Class.Plugin', APP_PATH);

/**
 * 11插件
 * @author 11
 */

    class 11Plugin extends Plugin{

        public $info = array(
            'name'=>'11',
            'title'=>'11',
            'description'=>' 11',
            'status'=>1,
            'author'=>'11',
            'version'=>'11'
        );

        public function install(){
            return true;
        }

        public function uninstall(){
            return true;
        }


    }