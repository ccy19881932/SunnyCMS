<?php

/**
 * 11模型
 */
class 11Model extends Model{

}
