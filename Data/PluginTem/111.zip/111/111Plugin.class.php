<?php

import('Class.Plugin', APP_PATH);

/**
 * 222插件
 * @author 444
 */

    class 111Plugin extends Plugin{

        public $info = array(
            'name'=>'111',
            'title'=>'222',
            'description'=>' 55',
            'status'=>1,
            'author'=>'444',
            'version'=>'333'
        );

        public function install(){
            return true;
        }

        public function uninstall(){
            return true;
        }

        //实现的otherhook钩子方法
        public function otherhook($param){

        }

    }