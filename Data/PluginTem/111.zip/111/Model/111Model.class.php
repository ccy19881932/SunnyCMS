<?php

/**
 * 111模型
 */
class 111Model extends Model{

}
