<?php

import('Class.Plugin', APP_PATH);

/**
 * 123插件
 * @author 阿萨
 */

    class 123Plugin extends Plugin{

        public $info = array(
            'name'=>'123',
            'title'=>'123',
            'description'=>' 撒旦',
            'status'=>1,
            'author'=>'阿萨',
            'version'=>'321'
        );

        public function install(){
            return true;
        }

        public function uninstall(){
            return true;
        }


    }