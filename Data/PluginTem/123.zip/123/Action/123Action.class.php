<?php

import('Admin.Action.Plugin', APP_PATH.GROUP_NAME);

class 123Action extends PluginAction{

}
