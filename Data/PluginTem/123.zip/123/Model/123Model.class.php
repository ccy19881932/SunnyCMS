<?php

/**
 * 123模型
 */
class 123Model extends Model{

}
