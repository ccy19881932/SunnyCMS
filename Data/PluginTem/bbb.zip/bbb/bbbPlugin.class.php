<?php

import('Class.Plugin', APP_PATH);

/**
 * bbb插件
 * @author bb
 */

    class bbbPlugin extends Plugin{

        public $info = array(
            'name'=>'bbb',
            'title'=>'bbb',
            'description'=>' bb',
            'status'=>1,
            'author'=>'bb',
            'version'=>'bbb'
        );

        public function install(){
            return true;
        }

        public function uninstall(){
            return true;
        }

        //实现的pageHeader钩子方法
        public function pageHeader($param){

        }

    }