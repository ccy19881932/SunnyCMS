<?php

import('Admin.Action.Plugin', APP_PATH.GROUP_NAME);

class ccyAction extends PluginAction{

}
