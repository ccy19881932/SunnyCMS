<?php

/**
 * ccy模型
 */
class ccyModel extends Model{

}
