<?php

import('Class.Plugin', APP_PATH);

/**
 * ccy插件
 * @author ccy
 */

    class ccyPlugin extends Plugin{

        public $info = array(
            'name'=>'ccy',
            'title'=>'ccy',
            'description'=>'ccy ',
            'status'=>1,
            'author'=>'ccy',
            'version'=>'1.1'
        );

        public function install(){
            return true;
        }

        public function uninstall(){
            return true;
        }

        //实现的pageHeader钩子方法
        public function pageHeader($param){

        }

    }