<?php

import('Admin.Action.Plugin', APP_PATH.GROUP_NAME);

class ccy123Action extends PluginAction{

}
