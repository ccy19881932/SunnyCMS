<?php

/**
 * ccy123模型
 */
class ccy123Model extends Model{

}
