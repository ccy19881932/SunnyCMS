<?php

import('Class.Plugin', APP_PATH);

/**
 * ccy123插件
 * @author ccy
 */

    class ccy123Plugin extends Plugin{

        public $info = array(
            'name'=>'ccy123',
            'title'=>'ccy123',
            'description'=>'ccy ',
            'status'=>1,
            'author'=>'ccy',
            'version'=>'1.1'
        );

        public function install(){
            return true;
        }

        public function uninstall(){
            return true;
        }

        //实现的pageHeader钩子方法
        public function pageHeader($param){

        }

    }