<?php

/**
 * df模型
 */
class dfModel extends Model{

}
