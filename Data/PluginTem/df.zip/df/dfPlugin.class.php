<?php

import('Class.Plugin', APP_PATH);

/**
 * dsf插件
 * @author dsf
 */

    class dfPlugin extends Plugin{

        public $info = array(
            'name'=>'df',
            'title'=>'dsf',
            'description'=>' df',
            'status'=>1,
            'author'=>'dsf',
            'version'=>'sdf'
        );

        public function install(){
            return true;
        }

        public function uninstall(){
            return true;
        }


    }