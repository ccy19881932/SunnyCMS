<?php

/**
 * fiveth模型
 */
class fivethModel extends Model{

}
