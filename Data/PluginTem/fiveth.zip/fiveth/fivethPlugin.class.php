<?php

import('Class.Plugin', APP_PATH);

/**
 * fiveth插件
 * @author ccy
 */

    class fivethPlugin extends Plugin{

        public $info = array(
            'name'=>'fiveth',
            'title'=>'fiveth',
            'description'=>' ',
            'status'=>1,
            'author'=>'ccy',
            'version'=>'1.1'
        );

        public function install(){
            return true;
        }

        public function uninstall(){
            return true;
        }

        //实现的pageHeader钩子方法
        public function pageHeader($param){

        }
        //实现的otherhook钩子方法
        public function otherhook($param){

        }

    }