<?php

import('Class.Plugin', APP_PATH);

/**
 * fourth插件
 * @author ccy
 */

    class fourthPlugin extends Plugin{

        public $info = array(
            'name'=>'fourth',
            'title'=>'fourth',
            'description'=>' ',
            'status'=>0,
            'author'=>'ccy',
            'version'=>'1.1'
        );

        public function install(){
            return true;
        }

        public function uninstall(){
            return true;
        }


    }