<?php

/**
 * hhh模型
 */
class hhhModel extends Model{

}
