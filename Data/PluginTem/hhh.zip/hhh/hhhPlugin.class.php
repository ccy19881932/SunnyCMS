<?php

import('Class.Plugin', APP_PATH);

/**
 * hh插件
 * @author hh
 */

    class hhhPlugin extends Plugin{

        public $info = array(
            'name'=>'hhh',
            'title'=>'hh',
            'description'=>' hh',
            'status'=>1,
            'author'=>'hh',
            'version'=>'hh'
        );

        public function install(){
            return true;
        }

        public function uninstall(){
            return true;
        }

        //实现的pageHeader钩子方法
        public function pageHeader($param){

        }

    }