<?php

/**
 * sdffdg模型
 */
class sdffdgModel extends Model{

}
