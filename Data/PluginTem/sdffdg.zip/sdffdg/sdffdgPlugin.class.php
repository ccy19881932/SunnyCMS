<?php

import('Class.Plugin', APP_PATH);

/**
 * dsffg插件
 * @author gf
 */

    class sdffdgPlugin extends Plugin{

        public $info = array(
            'name'=>'sdffdg',
            'title'=>'dsffg',
            'description'=>' gfd',
            'status'=>1,
            'author'=>'gf',
            'version'=>'dsf'
        );

        public function install(){
            return true;
        }

        public function uninstall(){
            return true;
        }

        //实现的pageHeader钩子方法
        public function pageHeader($param){

        }
        //实现的otherhook钩子方法
        public function otherhook($param){

        }

    }