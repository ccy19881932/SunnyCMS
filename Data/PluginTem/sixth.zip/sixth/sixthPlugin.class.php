<?php

import('Class.Plugin', APP_PATH);

/**
 * sixth插件
 * @author auth
 */

    class sixthPlugin extends Plugin{

        public $info = array(
            'name'=>'sixth',
            'title'=>'sixth',
            'description'=>' 111',
            'status'=>0,
            'author'=>'auth',
            'version'=>'2.2'
        );

        public function install(){
            return true;
        }

        public function uninstall(){
            return true;
        }


    }