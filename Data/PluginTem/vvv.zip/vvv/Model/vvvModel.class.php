<?php

/**
 * vvv模型
 */
class vvvModel extends Model{

}
