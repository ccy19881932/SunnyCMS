<?php

import('Class.Plugin', APP_PATH);

/**
 * ggg插件
 * @author ggg
 */

    class vvvPlugin extends Plugin{

        public $info = array(
            'name'=>'vvv',
            'title'=>'ggg',
            'description'=>' ggg',
            'status'=>1,
            'author'=>'ggg',
            'version'=>'ggg'
        );

        public function install(){
            return true;
        }

        public function uninstall(){
            return true;
        }

        //实现的pageHeader钩子方法
        public function pageHeader($param){

        }

    }