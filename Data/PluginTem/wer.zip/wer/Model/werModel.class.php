<?php

/**
 * wer模型
 */
class werModel extends Model{

}
