<?php

import('Class.Plugin', APP_PATH);

/**
 * ee插件
 * @author wer
 */

    class werPlugin extends Plugin{

        public $info = array(
            'name'=>'wer',
            'title'=>'ee',
            'description'=>' wer',
            'status'=>1,
            'author'=>'wer',
            'version'=>'wer'
        );

        public function install(){
            return true;
        }

        public function uninstall(){
            return true;
        }

        //实现的otherhook钩子方法
        public function otherhook($param){

        }

    }